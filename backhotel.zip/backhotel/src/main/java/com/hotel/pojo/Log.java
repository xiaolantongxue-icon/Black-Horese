package com.hotel.pojo;

import lombok.Data;

@Data
public class Log {
    private static final long serialVersionUID = 1L;
    private Integer id;
    private Integer	userId;
    private String operation;
    private String password;
    private String time;
    private String note;
}
