package com.hotel.pojo;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class Customer {
    private static final long serialVersionUID = 1L;
    private Integer id;
    private String name;
    private Integer sex;
    private String password;
    private String tele;
    private String email;
    private String address;
    private Integer integral;
    private Integer level;
    private LocalDateTime lastCtime;
    private LocalDateTime lastRtime;
    private String note;
}
