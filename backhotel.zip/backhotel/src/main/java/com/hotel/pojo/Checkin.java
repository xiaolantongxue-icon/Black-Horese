package com.hotel.pojo;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class Checkin {
    private static final long serialVersionUID = 1L;
    private Integer id;
    private String no;
    private String roomNumber;
    private Integer rommTypeId;
    private BigDecimal standardPrice;
    private BigDecimal discountPrice;
    private BigDecimal deposit;
    private String customerName;
    private Integer cardType;
    private String phone;
    private LocalDate arriveTime;
    private LocalDate leaveTime;
    private Integer customerSize;
    private Integer userId;
    private Integer customerId;
    private BigDecimal customerPrice;
    private Integer breakfastOrNot;
    private Integer remindOrNot;
    private String note;
}
