package com.hotel.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Floor {
    private static final long serialVersionUID = 1L;
    private Integer id;
    private String name;
    private String note;
}
