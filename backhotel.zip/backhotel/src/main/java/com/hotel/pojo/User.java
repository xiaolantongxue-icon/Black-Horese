package com.hotel.pojo;

import lombok.Data;

@Data
public class User {
    private static final long serialVersionUID = 1L;
    private Integer id;
    private String login;
    private String name;
    private String password;
    private Integer	permissions;
    private String note;
}
