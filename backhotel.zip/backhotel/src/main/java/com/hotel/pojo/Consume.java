package com.hotel.pojo;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class Consume {
    private static final long serialVersionUID = 1L;
    private Integer id;
    private String no;
    private BigDecimal roomNumber;
    private String goodsName;
    private Integer number;
    private BigDecimal goodsPrice;
    private BigDecimal consumeMoney;
    private BigDecimal discountRate;
    private BigDecimal discountMoney;
    private BigDecimal sumMoney;
    private Integer userId;
    private String date;
    private String note;
}
