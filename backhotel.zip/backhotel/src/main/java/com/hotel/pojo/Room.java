package com.hotel.pojo;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class Room {
    private static final long serialVersionUID = 1L;
    private Integer id;
    private String roomNumber;
    private Integer state;
    private BigDecimal standardPrice;
    private BigDecimal discountPrice;
    private BigDecimal ncustomerPrice;
    private BigDecimal vcustomerPrice;
    private String note;
}
