package com.hotel.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RoomType {
    private static final long serialVersionUID = 1L;
    private Integer id;
    /*
    *
    * 客房名称
    *
    * */
    private String name;
    /*
    * 额定人数
    * */
    private Integer	size;
    /*
    * 备注
    * */
    private String note;

}
