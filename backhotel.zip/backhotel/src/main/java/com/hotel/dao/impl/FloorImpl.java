package com.hotel.dao.impl;

import com.hotel.dao.FloorDao;
import com.hotel.pojo.Floor;
import com.hotel.until.JdbcUtil;

import java.util.List;

public class FloorImpl implements FloorDao {
    @Override
    public List<Floor> list() {
        return JdbcUtil.executeQuery("select id,name,note from floor", Floor.class);

    }

    @Override
    public int add(Floor floor) {
        return JdbcUtil.executeUpdate("insert into floor(name,note) values(?,?)",floor.getName(),floor.getNote());
    }

    @Override
    public Floor getById(int id) {
        return JdbcUtil.getById("select id,name,note from floor where id=?",Floor.class,id);
    }

    @Override
    public int update(Floor floor) {
        return JdbcUtil.executeUpdate("update floor set name=?,note=? where id=?",floor.getName(),floor.getNote(),floor.getId());
    }
}
