package com.hotel.dao.impl;

import com.hotel.dao.RoomTypeDao;
import com.hotel.pojo.RoomType;
import com.hotel.until.JdbcUtil;

import java.util.List;

public class RoomTypeImpl implements RoomTypeDao {

    @Override
    public List<RoomType> list() {
        return JdbcUtil.executeQuery("select id,name,size,note from roomtype",RoomType.class);
    }

    @Override
    public int add(RoomType roomtype) {
        return JdbcUtil.executeUpdate("insert into roomtype(name,size,note) values(?,?,?)",roomtype.getName(),roomtype.getSize(),roomtype.getNote());
    }

    @Override
    public RoomType getById(int id) {
        return JdbcUtil.getById("select id,name,size,note from roomtype where id=?",RoomType.class,id);
    }

    @Override
    public int update(RoomType roomtype) {
        return JdbcUtil.executeUpdate("update roomtype set name=?,size=?,note=? where id=?",roomtype.getName(),roomtype.getSize(),roomtype.getNote(),roomtype.getId());
    }


}
