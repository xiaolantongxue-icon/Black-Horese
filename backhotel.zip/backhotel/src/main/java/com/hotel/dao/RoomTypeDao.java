package com.hotel.dao;

import com.hotel.pojo.RoomType;

import java.util.List;

public interface RoomTypeDao {
    List<RoomType> list();
    int add(RoomType roomtype);
    RoomType getById(int id);
    int update(RoomType roomtype);
}
