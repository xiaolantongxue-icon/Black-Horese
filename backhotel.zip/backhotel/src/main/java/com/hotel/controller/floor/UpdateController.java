package com.hotel.controller.floor;
import com.hotel.pojo.Floor;
import com.hotel.service.FloorService;
import com.hotel.service.impl.FloorServiceImpl;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
@WebServlet("/floor/update")
public class UpdateController extends HttpServlet {
       FloorService floorService=new FloorServiceImpl();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //接收要修改的数据
        String id= request.getParameter("id");
        String name=request.getParameter("name");
        String note=request.getParameter("note");
       //把数据封装到对象中
        Floor floor=new Floor(
                Integer.valueOf(id)
                ,name
                ,note
                             );
        //调用服务层修改
        int i =floorService.update(floor);
        //输出返回值
        response.getWriter().write(String.valueOf(i));
    }
}
