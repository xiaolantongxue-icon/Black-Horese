package com.hotel.service;

import com.hotel.pojo.Floor;

import java.util.List;

public interface FloorService {
    List<Floor> list();
    int add(Floor floor);
    Floor getById(int id);
    int update(Floor floor);
}
