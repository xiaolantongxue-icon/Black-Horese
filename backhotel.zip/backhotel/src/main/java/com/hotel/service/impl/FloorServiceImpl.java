package com.hotel.service.impl;

import com.hotel.dao.FloorDao;
import com.hotel.dao.impl.FloorImpl;
import com.hotel.pojo.Floor;
import com.hotel.service.FloorService;

import java.util.List;

public class FloorServiceImpl implements FloorService {
    FloorDao floorDao=new FloorImpl();
    @Override
    public List<Floor> list() {
        return floorDao.list();
    }

    @Override
    public int add(Floor floor) {
        return floorDao.add(floor);
    }

    @Override
    public Floor getById(int id) {
        return floorDao.getById(id);
    }

    @Override
    public int update(Floor floor) {
        return floorDao.update(floor);
    }
}
