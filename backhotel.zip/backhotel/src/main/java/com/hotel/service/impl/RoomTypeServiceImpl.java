package com.hotel.service.impl;

import com.hotel.dao.RoomTypeDao;
import com.hotel.dao.impl.RoomTypeImpl;
import com.hotel.pojo.RoomType;
import com.hotel.service.RoomTypeService;

import java.util.List;

public class RoomTypeServiceImpl implements RoomTypeService {
    RoomTypeDao roomTypeDao=new RoomTypeImpl();

    @Override
    public List<RoomType> list() {
        return roomTypeDao.list();
    }

    @Override
    public int add(RoomType roomtype) {
        return roomTypeDao.add(roomtype);
    }

    @Override
    public RoomType getById(int id) {
        return roomTypeDao.getById(id);
    }

    @Override
    public int update(RoomType roomtype) {
        return roomTypeDao.update(roomtype);
    }
}
