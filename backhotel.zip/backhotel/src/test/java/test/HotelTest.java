package test;

import com.alibaba.fastjson.JSONObject;
import com.hotel.pojo.RoomType;
import com.hotel.service.RoomTypeService;
import com.hotel.service.impl.RoomTypeServiceImpl;

import java.util.List;

public class HotelTest {
    public static void main(String []args)
    {
        RoomTypeService roomTypeService=new RoomTypeServiceImpl();
        System.out.println(roomTypeService.list());
      /*  for(RoomType roomtype: roomTypeService.list()){
            System.out.println(roomtype.getId());
        }*/
      //转换json
        List<RoomType> list = roomTypeService.list();
        String str=JSONObject.toJSONString(list);
        System.out.println(str);
    }
}
